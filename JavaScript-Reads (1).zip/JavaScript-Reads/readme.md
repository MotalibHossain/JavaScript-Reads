<center>
<h1>JavaScripts Reads</h1>
<hr>
</center>
# Contents:

- [x] Selectors.
- [x] JavaScripts Events.
- [x] JavaScripts ndition.
- [x] JavaScripts functions.
    - [ ] Optional chaining.
    - [ ] Asynchronous callback.
    - [ ] callback pattern.
    - [ ] Clouser.
    - [ ] Hosting.
    - [ ] Passing function.
    - [ ] Defualt parameter.
    - [ ] Implecitt return.
    
- [x] Traversing.
- [x] Create form using click event using Jquery.
- [x] Create form using functional javascript.
- [x] Compleate javascript Crud Operations.
- [x] Compleate Jquery Crud Operations.
- [x] Jquery daterangepicker whole plugin.
- [x] Jquery DataTable plugin.



<<<<<<< HEAD
#Resource:

+ Events and own custom function: (https://stackoverflow.com/questions/18562616/date-range-picker-how-to-fire-an-event-on-entering-a-date)
+ Property List: (https://www.codegrepper.com/code-examples/whatever/get+value+daterangepicker+when+load+in+jquery
=======

    + [Events and own custom function] (https://stackoverflow.com/questions/18562616/date-range-picker-how-to-fire-an-event-on-entering-a-date)
    + [Property List](Property List:https://www.codegrepper.com/code-examples/whatever/get+value+daterangepicker+when+load+in+jquery)
>>>>>>> 1b999b91dc7127eb272c61d96e5e43001cc4dbb5
